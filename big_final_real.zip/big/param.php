<?php
$servername='localhost';
$user_name='root';
$password='123456';
$dbname='mobile_inf';
?>